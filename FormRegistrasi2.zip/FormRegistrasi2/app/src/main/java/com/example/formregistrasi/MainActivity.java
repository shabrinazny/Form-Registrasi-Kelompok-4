package com.example.formregistrasi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText nama, tempat, tglLahir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Inisialisasi Text Input
        nama = (EditText) findViewById(R.id.editNama);
        tempat = (EditText) findViewById(R.id.tempat);
        tglLahir = (EditText) findViewById(R.id.tglLahir);
    }

    public void submitRegis(View view) {

        Intent hubung = new Intent(this, HasilActivity.class);
        hubung.putExtra("nama", nama.getText().toString());
        hubung.putExtra("tempat", tempat.getText().toString());
        hubung.putExtra("tglLahir", tglLahir.getText().toString());
        startActivity(hubung);
    }
}