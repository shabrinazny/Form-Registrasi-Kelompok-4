package com.example.formregistrasi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class HasilActivity extends AppCompatActivity {

    TextView txt1, txt2, txt3;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);

        txt1 = (TextView) findViewById(R.id.namaUser);
        txt2 = (TextView) findViewById(R.id.tempatUser);
        txt3 = (TextView) findViewById(R.id.tglLahirUser);

        String nama = getIntent().getExtras().getString("nama");
        String tempat = getIntent().getExtras().getString("tempat");
        String tglLahir = getIntent().getExtras().getString("tglLahir");

        txt1.setText("Nama Anda\n"+nama);
        txt2.setText("Tempat Anda\n"+tempat);
        txt3.setText("Tanggal Lahir Anda\n"+tglLahir);

    }
}